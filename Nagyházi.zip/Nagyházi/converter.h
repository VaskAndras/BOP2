#ifndef CONVERTER_H
#define CONVERTER_H
#include <string>
#include "main.cpp"
class Converter {
private:
    std::string type; 
    bool form;
protected:
    Converter(int f, std::string t) : form(false), type(t) {}
    bool getform();
    std::string gettype();
    bool isstart(std::string test, int pos);
    bool isend(std::string test, int pos);
public:
    virtual Marker* createMarker(std::string text, int pos) = 0;
};

#endif // CONVERTER_H
