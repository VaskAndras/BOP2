#include "converter.h"

    Converter::Converter(int f, std::string t) : form(false), type(t) {}
    bool Converter::getform() {
        return form;
    }
    std::string Converter::gettype(){
        return type;
    }
    bool Converter::isstart(std::string test, int pos){
        // this check is for the characters before a special character
        // if there is a space or a newline or the beginning of the text, then it is a valid start for a marker
        return (pos == 0 || test[pos - 1] == ' ' || test[pos - 1] == '\n');
    }
    bool Converter::isend(std::string test, int pos){
        // this check is for the characters after a special character
        // if there is a space or a newline or the end of the text, then it is a valid end for a marker
        return (pos == test.size() - 1 || test[pos + 1] == ' ' || test[pos + 1] == '\n');
    }
    


    // This function will create an italic marker if the character at the given position is a '*' and it is a valid start for a marker
    Marker* Italic::createMarker(std::string text, int pos) override {
        if (text[pos] == '*' && isstart(text, pos)) {
            return new Italic(pos, 1);
        }
        return nullptr;
    }
};

    // This function will create an italic end marker if the character at the given position is a '*' and it is a valid end for a marker
    Marker* italic_end::createMarker(std::string text, int pos) override {
        if (text[pos] == '*' && isend(text, pos)) {
            return new italic_end(pos, 1);
        }
        return nullptr;
    }
};

bool Converter::isend(std::string test, int pos)
{
    return false;
}
